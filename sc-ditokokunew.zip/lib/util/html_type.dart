enum HtmlType {
  termsAndCondition,
  aboutUs,
  privacyPolicy,
  shippingPolicy,
  cancellation,
  refund
}