import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:get/get.dart';
import 'package:sixam_mart/util/styles.dart';
import 'package:sixam_mart/helper/price_converter.dart';
import 'package:sixam_mart/features/profile/controllers/profile_controller.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'TopUpService.dart';

class TopUpWebViewPage extends StatefulWidget {
  final String checkoutUrl;
  final String paymentMethod;
  final int amount;
  final String? reference; // Optional, akan diambil dari URL atau data lain

  const TopUpWebViewPage({
    super.key,
    required this.checkoutUrl,
    required this.paymentMethod,
    required this.amount,
    this.reference, // Buat optional
  });

  @override
  State<TopUpWebViewPage> createState() => _TopUpWebViewPageState();
}

class _TopUpWebViewPageState extends State<TopUpWebViewPage> {
  late final WebViewController _controller;
  bool _isLoading = true;
  String _pageTitle = '';
  bool _isProcessingPayment = false;
  String? _extractedReference;

  // Ganti dengan URL backend Anda
  static const String BACKEND_URL = 'https://api.ditokoku.id';

  @override
  void initState() {
    super.initState();
    _extractedReference = widget.reference; // Simpan reference jika ada
    _initializeWebView();
  }

  // Extract reference dari URL
  String? _extractReferenceFromUrl(String url) {
    try {
      final uri = Uri.parse(url);
      
      // 1. Coba ambil dari query parameter 'tripay_reference' (PRIORITAS PERTAMA)
      if (uri.queryParameters.containsKey('tripay_reference')) {
        final ref = uri.queryParameters['tripay_reference'];
        print('✅ Found tripay_reference: $ref');
        return ref;
      }
      
      // 2. Coba ambil dari query parameter 'reference'
      if (uri.queryParameters.containsKey('reference')) {
        final ref = uri.queryParameters['reference'];
        print('✅ Found reference: $ref');
        return ref;
      }
      
      // 3. Coba ambil dari query parameter 'merchant_ref'
      if (uri.queryParameters.containsKey('tripay_merchant_ref')) {
        final ref = uri.queryParameters['tripay_merchant_ref'];
        print('✅ Found tripay_merchant_ref: $ref');
        return ref;
      }
      
      // 4. Coba ambil dari path segment terakhir
      final segments = uri.pathSegments;
      if (segments.isNotEmpty) {
        final lastSegment = segments.last;
        // Cek apakah format seperti reference Tripay (biasanya T + angka)
        if (lastSegment.startsWith('T') && lastSegment.length > 5) {
          print('✅ Found reference from path: $lastSegment');
          return lastSegment;
        }
      }
      
      // 5. Coba cari pattern 'tripay_reference=' dalam URL
      final tripayMatch = RegExp(r'[?&]tripay_reference=([^&]+)').firstMatch(url);
      if (tripayMatch != null) {
        final ref = tripayMatch.group(1);
        print('✅ Found tripay_reference via regex: $ref');
        return ref;
      }
      
      // 6. Coba cari pattern 'reference=' dalam URL
      final match = RegExp(r'[?&]reference=([^&]+)').firstMatch(url);
      if (match != null) {
        final ref = match.group(1);
        print('✅ Found reference via regex: $ref');
        return ref;
      }
      
      print('❌ No reference found in URL: $url');
      
    } catch (e) {
      print('❌ Error extracting reference from URL: $e');
    }
    return null;
  }

  void _initializeWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            setState(() {
              _isLoading = true;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isLoading = false;
            });
            _controller.getTitle().then((title) {
              setState(() {
                _pageTitle = title ?? '';
              });
            });
          },
          onNavigationRequest: (NavigationRequest request) {
            print('Navigation to: ${request.url}');
            
            // Extract reference dari URL jika belum ada
            if (_extractedReference == null) {
              _extractedReference = _extractReferenceFromUrl(request.url);
              if (_extractedReference != null) {
                print('✅ Reference extracted from URL: $_extractedReference');
              }
            }
            
            // Deteksi halaman success/redirect dari payment gateway
            if (_isSuccessUrl(request.url)) {
              if (!_isProcessingPayment) {
                _checkPaymentStatus(); // CEK STATUS DULU
              }
              return NavigationDecision.prevent;
            }
            
            if (_isFailureUrl(request.url)) {
              _handlePaymentFailed();
              return NavigationDecision.prevent;
            }
            
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.checkoutUrl));
  }

  bool _isSuccessUrl(String url) {
    return url.contains('success') || 
           url.contains('completed') ||
           url.contains('/tripay/success') ||
           url.contains('status=success');
  }

  bool _isFailureUrl(String url) {
    return url.contains('failed') || 
           url.contains('cancelled') ||
           url.contains('/tripay/failed') ||
           url.contains('status=failed');
  }

  // FUNGSI BARU: Cek status pembayaran via API
  Future<void> _checkPaymentStatus() async {
    if (_isProcessingPayment) return;
    
    // Validasi reference
    if (_extractedReference == null || _extractedReference!.isEmpty) {
      print('❌ ERROR: Reference not found');
      _showErrorSnackbar();
      return;
    }
    
    setState(() {
      _isProcessingPayment = true;
    });

    print('======== CHECKING PAYMENT STATUS ========');
    print('Reference: $_extractedReference');
    print('Timestamp: ${DateTime.now().toIso8601String()}');

    try {
      _showProcessingDialog();

      // Panggil API status check
      final response = await http.get(
        Uri.parse('$BACKEND_URL/api/tripay/status/$_extractedReference'),
        headers: {'Content-Type': 'application/json'},
      );

      print('Status API Response Code: ${response.statusCode}');
      print('Status API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final status = data['data']?['status'] ?? '';
        
        print('Payment Status: $status');

        if (status == 'PAID') {
          // Status PAID -> Lanjut proses add funds
          print('✅ Status is PAID - Processing payment');
          await _handlePaymentSuccess();
        } else {
          // Status selain PAID -> Tampilkan pesan
          print('⚠️ Status is not PAID (Status: $status)');
          Navigator.of(context).pop(); // Close loading dialog
          _showPendingPaymentSnackbar();
          setState(() {
            _isProcessingPayment = false;
          });
        }
      } else {
        throw Exception('Failed to check status: ${response.statusCode}');
      }

    } catch (e) {
      print('ERROR: Status check failed: $e');
      Navigator.of(context).pop(); // Close loading dialog
      _showErrorSnackbar();
      setState(() {
        _isProcessingPayment = false;
      });
    }
  }

  Future<void> _handlePaymentSuccess() async {
    print('======== PROCESSING PAID PAYMENT ========');
    print('Payment Method: ${widget.paymentMethod}');
    print('Amount: ${widget.amount}');

    try {
      final profileController = Get.find<ProfileController>();
      final initialBalance = profileController.userInfoModel?.walletBalance ?? 0;
      print('Initial wallet balance: $initialBalance');

      print('--- Attempting to add funds ---');
      await _tryAddFundsWithTopUpService();

      print('--- Refreshing user profile ---');
      await _refreshUserProfile();

      final finalBalance = profileController.userInfoModel?.walletBalance ?? 0;
      print('Final wallet balance: $finalBalance');
      print('Balance difference: ${finalBalance - initialBalance}');

      Navigator.of(context).pop(); // Close loading dialog
      _showSuccessMessage();
      _navigateBack();

      print('======== PAYMENT PROCESSING COMPLETED ========');

    } catch (e) {
      print('ERROR: Payment processing failed: $e');
      
      if (Navigator.canPop(context)) {
        Navigator.of(context).pop();
      }

      print('--- Doing fallback profile refresh ---');
      await _refreshUserProfile();
      
      _showProcessingMessage();
      _navigateBack();
    }
  }

  Future<void> _tryAddFundsWithTopUpService() async {
    try {
      print('=== Using TopUpService.addFundsToWallet ===');
      
      final result = await TopUpService.addFundsToWallet(
        amount: widget.amount.toDouble(),
        reference: _extractedReference ?? 'TOPUP_${DateTime.now().millisecondsSinceEpoch}',
      );
      
      print('TopUpService result:');
      print('  Success: ${result.success}');
      print('  Message: ${result.message}');
      
      if (result.success) {
        print('SUCCESS: Funds added via TopUpService');
        return;
      } else {
        throw Exception('TopUpService failed: ${result.message}');
      }
      
    } catch (e) {
      print('CRITICAL ERROR: TopUpService.addFundsToWallet failed');
      print('Error: $e');
      throw e;
    }
  }

  Future<void> _refreshUserProfile() async {
    try {
      print('Getting ProfileController instance...');
      final profileController = Get.find<ProfileController>();
      
      print('Current wallet balance before refresh: ${profileController.userInfoModel?.walletBalance}');
      
      await profileController.getUserInfo();
      
      print('Wallet balance after refresh: ${profileController.userInfoModel?.walletBalance}');
      
      if (mounted) {
        setState(() {});
      }
      
      print('Profile refresh completed successfully');
    } catch (e) {
      print('ERROR: Failed to refresh profile: $e');
    }
  }

  void _handlePaymentFailed() {
    _showFailureMessage();
    _navigateBack();
  }

  void _showProcessingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => WillPopScope(
        onWillPop: () async => false,
        child: const Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Memproses pembayaran...'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showSuccessMessage() {
    Get.showSnackbar(GetSnackBar(
      backgroundColor: Colors.green,
      message: 'Pembayaran berhasil! Saldo telah ditambahkan',
      duration: const Duration(seconds: 3),
      snackStyle: SnackStyle.FLOATING,
      margin: const EdgeInsets.all(16),
      borderRadius: 8,
    ));
  }

  void _showPendingPaymentSnackbar() {
    Get.showSnackbar(GetSnackBar(
      backgroundColor: Colors.orange,
      message: 'Pembayaran belum diterima, silahkan refresh',
      duration: const Duration(seconds: 4),
      snackStyle: SnackStyle.FLOATING,
      margin: const EdgeInsets.all(16),
      borderRadius: 8,
      mainButton: TextButton(
        onPressed: () {
          Get.back(); // Close snackbar
          _checkPaymentStatus(); // Retry check
        },
        child: const Text('REFRESH', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    ));
  }

  void _showErrorSnackbar() {
    Get.showSnackbar(GetSnackBar(
      backgroundColor: Colors.red,
      message: 'Gagal mengecek status pembayaran',
      duration: const Duration(seconds: 3),
      snackStyle: SnackStyle.FLOATING,
      margin: const EdgeInsets.all(16),
      borderRadius: 8,
    ));
  }

  void _showProcessingMessage() {
    Get.showSnackbar(GetSnackBar(
      backgroundColor: Colors.blue,
      message: 'Pembayaran berhasil! Saldo sedang diproses',
      duration: const Duration(seconds: 3),
      snackStyle: SnackStyle.FLOATING,
      margin: const EdgeInsets.all(16),
      borderRadius: 8,
    ));
  }

  void _showFailureMessage() {
    Get.showSnackbar(GetSnackBar(
      backgroundColor: Colors.red,
      message: 'Pembayaran gagal atau dibatalkan',
      duration: const Duration(seconds: 3),
      snackStyle: SnackStyle.FLOATING,
      margin: const EdgeInsets.all(16),
      borderRadius: 8,
    ));
  }

  void _navigateBack() {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        Navigator.of(context).popUntil((route) => route.isFirst);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          onPressed: () => _showExitDialog(),
          icon: const Icon(Icons.arrow_back, color: Colors.black),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _pageTitle.isNotEmpty ? _pageTitle : 'Pembayaran',
              style: robotoBold.copyWith(fontSize: 16, color: Colors.black),
            ),
            Text(
              '${widget.paymentMethod} • ${PriceConverter.convertPrice(widget.amount.toDouble())}',
              style: robotoRegular.copyWith(fontSize: 12, color: Colors.grey[600]),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => _controller.reload(),
            icon: const Icon(Icons.refresh, color: Colors.black),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            Container(
              color: Colors.white,
              child: const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Memuat halaman pembayaran...', style: TextStyle(fontSize: 14, color: Colors.grey)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _showExitDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Batalkan Pembayaran?', style: robotoBold.copyWith(fontSize: 18, color: Colors.black)),
        content: Text('Apakah Anda yakin ingin membatalkan proses pembayaran?', style: robotoRegular.copyWith(fontSize: 14, color: Colors.black)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tidak', style: robotoRegular.copyWith(fontSize: 14, color: Colors.black)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text('Ya, Batalkan', style: robotoBold.copyWith(fontSize: 14, color: Colors.red)),
          ),
        ],
      ),
    );
  }
}